package algeo;
import java.text.DecimalFormat;
import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        
        SPL SP = new SPL();
        SP.BacaPersamaanInterpolasiFILE("file.txt");
        Matriks M = new Matriks(SP.GetNPL(),SP.GetNmax()+1);
        M.SPLtoMatriks(SP);
        M.TulisMatriks();   

    }
    
}