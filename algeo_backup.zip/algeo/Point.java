package algeo;
import java.util.Scanner;
import java.lang.Math;

public class Point{
    private double x;
    private double y;

    public Point() {
        this.x = 0;
        this.y = 0;
    }

    public double GetX() {
        return this.x;
    }
    
    public double GetY() {
        return this.y;
    }

    public void BacaPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }


}

